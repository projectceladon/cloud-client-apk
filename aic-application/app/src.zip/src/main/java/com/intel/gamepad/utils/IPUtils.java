package com.intel.gamepad.utils;

import com.jeremy.fastsharedpreferences.FastSharedPreferences;
import com.mycommonlibrary.utils.LogEx;

public class IPUtils {
    public static final String DEFAULT_IP = "http://192.168.1.2:80/";
//    public static final String DEFAULT_IP = "http://www.intelcloudplay.com/";

    public static void save(String IP) {
        FastSharedPreferences.get("ip_file").edit().putString("ip", IP).commit();
    }

    public static String load() {
        String ip = FastSharedPreferences.get("ip_file").getString("ip", DEFAULT_IP);
        LogEx.i(ip);
        return ip;
    }
}
