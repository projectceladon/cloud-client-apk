package com.intel.gamepad.activity

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Message

import android.view.*
import android.widget.PopupWindow
import androidx.appcompat.app.AppCompatActivity
import androidx.collection.SimpleArrayMap
import androidx.core.view.doOnPreDraw
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.intel.gamepad.R
import com.intel.gamepad.app.AppConst
import com.intel.gamepad.app.MyApp
import com.intel.gamepad.bean.MouseBean
import com.intel.gamepad.controller.impl.DeviceSwitchListtener
import com.intel.gamepad.controller.webrtc.*
import com.intel.gamepad.owt.p2p.P2PHelper
import com.intel.gamepad.utils.AudioHelper
import com.intel.gamepad.utils.IPUtils
import com.intel.gamepad.utils.NetSpeedUtils
import com.intel.gamepad.utils.PingUtils
import com.jeremy.fastsharedpreferences.FastSharedPreferences
import com.lzy.okgo.OkGo
import com.lzy.okgo.callback.StringCallback
import com.lzy.okgo.model.Response
import com.mcxtzhang.commonadapter.rv.CommonAdapter
import com.mcxtzhang.commonadapter.rv.ViewHolder
import com.mycommonlibrary.utils.*
import kotlinx.android.synthetic.main.activity_play_game_rtc.*
import kotlinx.coroutines.*
import org.jetbrains.anko.longToast
import org.jetbrains.anko.startActivityForResult
import org.json.JSONObject
import org.webrtc.RTCStatsReport
import org.webrtc.RendererCommon
import org.webrtc.SingletonSurfaceView
import owt.base.ActionCallback
import owt.base.OwtError
import owt.p2p.P2PClient
import owt.p2p.RemoteStream
import java.lang.ref.WeakReference
import java.nio.ByteBuffer
import java.util.*

private const val SERVER_SCREEN_WIDTH = 1920
private const val SERVER_SCREEN_HEIGHT = 1080
private const val DELAY_GET_STATUS = 3000L

class PlayGameRtcActivity : AppCompatActivity(), DeviceSwitchListtener,
    CoroutineScope by MainScope() {
    companion object {
        const val RESULT_MSG = "resultMsg"
        fun actionStart(act: Activity, controller: String, gameId: Int, gameName: String) {
            act.startActivityForResult<PlayGameRtcActivity>(
                AppConst.REQUEST_GAME,
                "controller" to controller,
                "gameId" to gameId,
                "gameName" to gameName
            )
        }
    }

    private var peerId: String = ""
    private var inCalling = false
    private var remoteStream: RemoteStream? = null
    private var remoteStreamEnded = false
    private var controller: BaseController? = null
    private var viewWidth = DensityUtils.getmScreenWidth()
    private var viewHeight = DensityUtils.getmScreenHeight()
    private var paddingSize = 0
    private var handler: Handler? = null
    private var firstTimestamp = 0L
    private var isFirst = false

    override fun onCreate(savedInstanceState: Bundle?) {
        initUIFeature()// 设置窗口特性
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_play_game_rtc)
        initAudioManager()
        initP2PClient()
        controller = selectGamePad()
        onConnectRequest(P2PHelper.serverIP, P2PHelper.clientId)

        chkStatusTitle.setOnClickListener {
            tvMyStatus.visibility = if (chkStatusTitle.isChecked) View.VISIBLE else View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        hideStatusBar()
//        layoutController.doOnPreDraw { fitScreenSize() }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler?.removeMessages(AppConst.MSG_SHOW_CONTROLLER)
        cancel()
    }

    override fun onBackPressed() {
        Message.obtain(handler, AppConst.MSG_QUIT, AppConst.EXIT_NORMAL).sendToTarget()
    }

    private fun initAudioManager() {
        AudioHelper.getInstance(this)
    }

    /**
     * 初始化窗口特性
     */
    private fun initUIFeature() {
        StatusBarUtil.setTranslucentStatus(this)
        // 全屏，无状态，无导航栏
        this.supportRequestWindowFeature(Window.FEATURE_NO_TITLE);//去掉标题栏
        this.window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );//去掉信息栏
        hideStatusBar()
    }

    private fun hideStatusBar() {
        window.addFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            val v = this.window.decorView
            v.systemUiVisibility = View.GONE
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            val decorView = window.decorView
            val uiOptions = (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
            decorView.systemUiVisibility = uiOptions
        }
    }

    /**
     * 初始化P2P客户端
     */
    private fun initP2PClient() {
        P2PHelper.init(this, object : P2PClient.P2PClientObserver {
            override fun onDataReceived(peerId: String, message: String) {
                if (!JSONObject(message).isNull("type")) {
                    val type = JSONObject(message).getString("type")
                    if (type == "cursor") {
                        LogEx.i(message)
                        parseMouseCursor(message)
                    }
                }
            }

            override fun onStreamAdded(remoteStream: RemoteStream) {
                runOnUiThread { if (!isFirst) fitScreenSize() }
//                P2PHelper.getClient().getStats(P2PHelper.serverIP, object :
//                    ActionCallback<RTCStatsReport> {
//                    override fun onSuccess(p0: RTCStatsReport) {
//                        p0.statsMap.values.forEach {
//                          LogEx.i(it.toString())
//                        }
//                    }
//
//                    override fun onFailure(p0: OwtError?) {
//                    }
//
//                })
                this@PlayGameRtcActivity.remoteStream = remoteStream
                remoteStream.addObserver(object : owt.base.RemoteStream.StreamObserver {
                    override fun onUpdated() {
                    }

                    override fun onEnded() {
                        remoteStreamEnded = true
                    }
                })
//                if (fullRenderer != null && remoteStream.hasVideo()) {
//                    remoteStream.attach(fullRenderer)
//                }
            }

            override fun onServerDisconnected() {
                LogEx.e("服务连接断开")
                Message.obtain(getHandler(), AppConst.MSG_QUIT, AppConst.EXIT_DISCONNECT)
                    .sendToTarget()
            }

        })

        initFullRender()
    }

    /**
     * 解析服务器回传的鼠标数据
     */
    private fun parseMouseCursor(message: String) = launch(Dispatchers.IO) {
        val bean = MouseBean.objectFromData(message)

        var top = 0
        var left = 0
        var curWidth = 0
        var curHeight = 0
        val dst = bean.dstRect
        dst?.let {
            top = it.top
            left = it.left
            curWidth = bean.width
            curHeight = bean.height
        }
        LogEx.i("${message.length}")
        try {
            withContext(Dispatchers.Main) {
                controller?.setMouseData(
                    left + (paddingSize / 2), top,
                    curWidth, curHeight, bean.isVisible
                )
            }
            LogEx.i("${bean.cursorData?.size} ${bean.isNoShapeChange}")
            if (!bean.cursorData.isNullOrEmpty() && !bean.isNoShapeChange) {
                // 解析鼠标光标
                val bmpCursor = buildCursor(bean.width, bean.height, bean.cursorData)
                withContext(Dispatchers.Main) {
                    controller?.setMouseCursor(bmpCursor)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 将服务端回传的鼠标图形数组转换成Bitmap对象
     */
    private fun buildCursor(width: Int, height: Int, curData: List<Byte>): Bitmap {
        val bgraData = ByteArray(width * height * 4)
        System.arraycopy(
            curData.toTypedArray().toByteArray(),
            0,
            bgraData,
            0,
            width * height * 4
        )
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val buf = ByteBuffer.wrap(bgraData)
        bitmap.copyPixelsFromBuffer(buf)
        return bitmap
    }

    /**
     * 初始化全屏渲染
     */
    private fun initFullRender() {
//        fullRenderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
//        fullRenderer.setEnableHardwareScaler(true)
//        fullRenderer.init(P2PHelper.getInst().rootEglBase.eglBaseContext, null)
//        this.lifecycle.addObserver(object : LifecycleObserver {
//            @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
//            fun onDestory() {
//                fullRenderer.release()
//            }
//        })
        SingletonSurfaceView.getInstance().surfaceView = fullRenderer
    }

    /**
     * 向信令服务器发登录请求
     * @param server 信令服务器的地址
     * @param myId 给当前设备设置个名称
     */
    private fun onConnectRequest(server: String, myId: String) {
        // 登录信令服的参数
        val jsonLogin = JSONObject(mapOf("host" to server, "token" to myId)).toString()
        LogEx.i("$jsonLogin")
        // 连接信令服
        P2PHelper.getClient()?.let {
            it.addAllowedRemotePeer(myId)
            it.connect(jsonLogin, object : ActionCallback<String> {
                override fun onSuccess(result: String) {
                    LogEx.i("$result ${Thread.currentThread().name}")
                    runOnUiThread { onCallRequest(P2PHelper.peerId) }
                }

                override fun onFailure(error: OwtError) {
                    LogEx.e("${error.errorMessage} ${error.errorCode}")
                    runOnUiThread {
                        longToast("连接服务器失败 ${error.errorMessage} ${error.errorCode}")
                        finish()
                    }
                }
            })
        }
    }

    /**
     * 获取远程服务端数据流并显示画面
     */
    private fun onCallRequest(peerId: String) {
        inCalling = true
        this.peerId = peerId

        // 添加服务端ID
        P2PHelper.getClient()?.addAllowedRemotePeer(peerId)
//        远程数据流附加到屏幕渲染器
//        remoteStream?.let {
//            if (!remoteStreamEnded) it.attach(fullRenderer)
//        }
        // 向服务端发送启动命令
        P2PHelper.getClient()?.send(peerId, "start", object : ActionCallback<Void> {
            override fun onSuccess(result: Void?) {
                LogEx.i("start message send success ${Thread.currentThread().name}")
                sendSizeChange() // 发送窗口尺寸消息给信令服

                runOnUiThread {
                    // 实例一个消息机制用于定时刷新信令服状态
                    val handler = StatusHandler()
                    handler.obtainMessage(AppConst.MSG_UPDATE_STATUS).sendToTarget()

                    lifecycle.addObserver(object : LifecycleObserver {
                        @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
                        fun onDestroy() {
                            handler.removeCallbacksAndMessages(null)
                        }
                    })
                }

            }

            override fun onFailure(error: OwtError?) {
                LogEx.e(error?.errorMessage + " " + error?.errorCode)
            }
        })
    }

    private fun getStatus(id: String) {
        P2PHelper.getClient()?.getStats(id, object : ActionCallback<RTCStatsReport> {
            override fun onSuccess(report: RTCStatsReport) {
                LogEx.i("$id:$report")

                var videoBytesR = ""
                var videoLostRate = 0.0
                var audioBytesR = ""
                var audioLostRate = 0.0
                var width = 0
                var height = 0
                report.statsMap.values.forEach {
                    if (it.type == "inbound-rtp") {
                        LogEx.i("${it.timestampUs}")
                        if (firstTimestamp == 0L) firstTimestamp = it.timestampUs.toLong()
                        val timestamp = it.timestampUs.toLong()

                        val br = it.members["bytesReceived"].toString().toLong()
                        val kbps =
                            if (br > 0 && (timestamp - firstTimestamp) > 0)
                                br / 1024 / ((timestamp - firstTimestamp) / 1000000)
                            else
                                0L
                        LogEx.i("$br $kbps}")

                        val pr = it.members["packetsReceived"].toString().toLong()
                        val pl = it.members["packetsLost"].toString().toLong()
                        val fl = it.members["fractionLost"].toString().toDouble()
                        LogEx.i("$pr $pl $fl ${it.members["mediaType"]}")

                        if (it.members["mediaType"] == "video") {
                            videoBytesR = "$kbps kbps"
                            videoLostRate = fl
                        } else {
                            audioBytesR = "$kbps kbps"
                            audioLostRate = fl
                        }

                    }
                    if (it.type == "track") {
                        if (it.members["kind"] == "video" && it.members["frameWidth"] != null && it.members["frameHeight"] != null) {
                            width = it.members["frameWidth"]?.toString()?.toInt() ?: 0
                            height = it.members["frameHeight"]?.toString()?.toInt() ?: 0
                        }
                    }
                }
                val time = DateTimeUtils.long2strDate("HH:mm:ss", System.currentTimeMillis())
                val clientReport = "--- inBound ---" +
                        "\nCurrent Time: $time" +
                        "\nScreen Size: $width X $height" +
                        "\nVideo BytesReceived: $videoBytesR" +
                        "\nVideo PacketLostRate: $videoLostRate" +
                        "\n" +
                        "\nAudio BytesReceived: $audioBytesR" +
                        "\nAudio PacketLostRate: $audioLostRate"
                runOnUiThread {
                    tvMyStatus.text = clientReport
                    val show = FastSharedPreferences.get("show_status").getBoolean("show", false)
                    layoutStatus.visibility = if (show) View.VISIBLE else View.GONE
                    tvMyStatus.visibility =
                        if (chkStatusTitle.isChecked) View.VISIBLE else View.GONE
                }
            }

            override fun onFailure(err: OwtError) {
                LogEx.e(err.errorMessage + " " + err.errorCode)
            }
        })
    }

    private inner class StatusHandler : Handler() {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
//            getStatus(P2PHelper.peerId)
            val show = FastSharedPreferences.get("show_status").getBoolean("show", false)
            if (show) {
                getStatus(P2PHelper.peerId)
                getStatus(P2PHelper.clientId)
            }
            // 发送心跳包
            val gameId = intent.getIntExtra("gameId", 0)
            val gameName = intent.getStringExtra("gameName") ?: ""
            requestOnline(gameId, gameName)

//            // 网络延时
//            launch(Dispatchers.IO) {
//                val ip = P2PHelper.serverIP
//                    .substringAfter("http://")
//                    .substringBefore(":8095")
//                val ping = PingUtils.getPing(ip)
//                withContext(Dispatchers.Main) {
//                    tvNetDelay.text = "${PingUtils.parseAvgDelay(ping)}ms"
//                }
//            }
            // 网速
            tvNetSpeed.text = NetSpeedUtils.showNetSpeed()

            sendEmptyMessageDelayed(AppConst.MSG_UPDATE_STATUS, DELAY_GET_STATUS)
        }
    }

    /**
     * 调整视频画面的比例
     */
    private fun fitScreenSize() {
        // 获取渲染器的宽和高，并根据服务器屏幕宽和高的比例计算出手机端屏幕的内边距
        viewWidth = fullRenderer.width
        viewHeight = fullRenderer.height
        val paddingWidth =
            if (viewWidth > SERVER_SCREEN_WIDTH)
                viewWidth - (SERVER_SCREEN_WIDTH * viewHeight / SERVER_SCREEN_HEIGHT)
            else 0

        val paddingHeight =
            if (viewHeight > SERVER_SCREEN_HEIGHT)
                viewHeight - SERVER_SCREEN_HEIGHT
            else 0
        LogEx.i(" $paddingWidth $viewWidth $viewHeight ${(SERVER_SCREEN_WIDTH * viewHeight / SERVER_SCREEN_HEIGHT)}")
        // 调整布局的边距，使渲染器居中
        layoutRenderBox.setPadding(paddingWidth / 2, 0, paddingWidth / 2, paddingHeight)
        viewWidth -= paddingWidth
        // 发送调整后的渲染器尺寸
        sendSizeChange()
        controller?.setViewDimenson(
            viewWidth,
            viewHeight,
            if (paddingWidth > 0) paddingWidth / 2 else 0,
            paddingHeight
        )
        isFirst = true
    }

    /**
     * 向服务器端发送渲染器的尺寸，服务端在收到鼠标坐标时会根据这个尺寸换算成服务器屏幕的坐标值
     */
    private fun sendSizeChange() {
        val mapRenderSize = mapOf(
            "width" to viewWidth,
            "height" to viewHeight
        )
        val mapParams = mapOf(
            "rendererSize" to mapRenderSize,
            "mode" to "stretch"
        )
        val mapData = mapOf(
            "event" to "sizechange",
            "parameters" to mapParams
        )
        val mapKey = mapOf(
            "type" to "control",
            "data" to mapData
        )
        val jsonString = JSONObject(mapKey).toString()
        LogEx.i(jsonString)

        P2PHelper.getClient()
            ?.send(P2PHelper.peerId, jsonString, object : P2PHelper.FailureCallBack<Void>() {
                override fun onFailure(err: OwtError?) {
                    LogEx.e("${err?.errorMessage} ${err?.errorCode}")
                }
            })
    }

    /**
     * 初始化游戏手柄
     */
    private fun selectGamePad(): BaseController {
        return when (intent.getStringExtra("controller").toUpperCase()) {
            RTCControllerXBox.NAME -> RTCControllerXBox(this, getHandler(), this)
            RTCControllerFPS.NAME -> RTCControllerFPS(this, getHandler(), this)
            RTCControllerRAC.NAME -> RTCControllerRAC(this, getHandler(), this)
            RTCControllerACT.NAME -> RTCControllerACT(this, getHandler(), this)
            RTCControllerMouse.NAME -> RTCControllerMouse(this, getHandler(), this)
            RTCControllerAndroid.NAME -> RTCControllerAndroid(this, getHandler(), this)
            else -> RTCControllerXBox(this, getHandler(), this)
        }
    }

    private fun getHandler(): Handler {
        if (handler == null) handler = GameHandler(this)
        return handler as Handler
    }

    /**
     * 自定义消息机制，接收来自GAClient的消息后，根据消息的what值做不同的处理
     */
    class GameHandler internal constructor(act: PlayGameRtcActivity) : Handler() {
        private val ref: WeakReference<PlayGameRtcActivity> = WeakReference(act)

        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            val act = ref.get()
            when (msg.what) {
                AppConst.MSG_QUIT -> {
                    LogEx.i("Exit Result" + msg.arg1)
                    act?.let {
                        val intent = it.intent
                        intent.putExtra(RESULT_MSG, msg.arg1)
                        it.setResult(Activity.RESULT_OK, intent)
                        it.finish()
                    }
                }
                AppConst.MSG_SHOW_CONTROLLER -> act?.showOrHideController()
                AppConst.MSG_UPDATE_CONTROLLER -> act?.updateControllerStatus()
            }
        }
    }

    /**
     * 在指定时长后隐藏游戏控制器（手柄）
     */
    private fun showOrHideController() {
        if (controller == null || handler == null) return
        updateControllerStatus()
        handler?.sendEmptyMessageDelayed(AppConst.MSG_SHOW_CONTROLLER, 1000)
    }

    private fun updateControllerStatus() {
        if ((System.currentTimeMillis() - BaseController.lastTouchMillis) > 10000)
            controller?.view?.alpha = 0f
        else {
            controller?.view?.alpha = 1f
        }
    }

    override fun switchKeyBoard() {
        controller?.let { layoutController.removeView(it.view) }
        controller = RTCControllerKeyBoard(this, getHandler(), this)
    }

    override fun switchMapperPad() {
        controller?.let { layoutController.removeView(it.view) }
        controller = selectGamePad()
    }

    override fun switchGamePad() {
        controller?.let { layoutController.removeView(it.view) }
        controller = RTCControllerXBox(this, getHandler(), this)
    }

    override fun showDeviceMenu() {
        controller?.view?.visibility = View.GONE
        // 初始化菜单布局
        val view = LayoutInflater.from(this).inflate(R.layout.game_device_switch, null, false)
        // 实例化对话框并加载布局
        val pw = PopupWindow(
            view,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        initRvController(view, pw)
        view.findViewById<View>(R.id.ibtnExit).setOnClickListener { pw.dismiss() }
        // 设置对话框属性
        pw.setOnDismissListener { controller?.view?.visibility = View.VISIBLE }
        pw.contentView = view
        pw.setBackgroundDrawable(ColorDrawable())
        pw.isOutsideTouchable = true
        pw.showAtLocation(layoutContainer, Gravity.CENTER, 0, 0)
    }

    private fun initRvController(view: View, pw: PopupWindow) {
        val mapCtrl = SimpleArrayMap<String, String>()
        mapCtrl.put(RTCControllerXBox.DESC, RTCControllerXBox.NAME)
        mapCtrl.put(RTCControllerFPS.DESC, RTCControllerFPS.NAME)
        mapCtrl.put(RTCControllerRAC.DESC, RTCControllerRAC.NAME)
        mapCtrl.put(RTCControllerACT.DESC, RTCControllerACT.NAME)
        mapCtrl.put(RTCControllerKeyBoard.DESC, RTCControllerKeyBoard.NAME)

        val listDesc = ArrayList<String>()
        for (i in 0 until mapCtrl.size()) {
            listDesc.add(mapCtrl.keyAt(i))
        }

        val rvController = view.findViewById<RecyclerView>(R.id.rvController)
        rvController.layoutManager = LinearLayoutManager(this)
        rvController.adapter =
            object : CommonAdapter<String>(this, listDesc, R.layout.item_controller) {
                override fun convert(vh: ViewHolder, ctrlDesc: String) {
                    vh.setText(R.id.chkController, ctrlDesc)
                    vh.setChecked(R.id.chkController, controller?.description == ctrlDesc)
                    vh.setOnClickListener(R.id.chkController) {
                        pw.dismiss()
                        if (ctrlDesc == RTCControllerKeyBoard.DESC) {
                            pw.dismiss()
                            switchKeyBoard()
                        } else {
                            intent.putExtra("controller", mapCtrl.get(ctrlDesc))
                            switchMapperPad()
                        }
                    }
                }

            }
    }

    /**
     * 在线心跳包
     */
    private fun requestOnline(gameId: Int, gameName: String) {
        OkGo.get<String>(IPUtils.load() + AppConst.ONLINE)
            .params("iid", gameId)
            .params("gameName", gameName)
            .params("gamedir", MyApp.pId)
            .params("gameIp", P2PHelper.serverIP.substringAfter("http://").substringBefore(":8095"))
            .execute(object : StringCallback() {
                override fun onSuccess(response: Response<String>) {
                }
            })
    }

}

