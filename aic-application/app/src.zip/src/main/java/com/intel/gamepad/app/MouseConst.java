package com.intel.gamepad.app;

public class MouseConst {
    public static final int LEFT = 1;
    public static final int MIDDEL = 2;
    public static final int RIGHT = 3;
}
