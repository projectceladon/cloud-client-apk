package com.intel.gamepad.owt.p2p;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;

import com.intel.gamepad.app.MyApp;

import org.webrtc.EglBase;

import owt.base.ActionCallback;
import owt.base.ContextInitialization;
import owt.base.VideoEncodingParameters;
import owt.p2p.P2PClient;
import owt.p2p.P2PClientConfiguration;

import static owt.base.MediaCodecs.VideoCodec.H264;
import static owt.base.MediaCodecs.VideoCodec.H265;
import static owt.base.MediaCodecs.VideoCodec.VP8;
import static owt.base.MediaCodecs.VideoCodec.VP9;

public class P2PHelper {
    public static String serverIP = "";
    public static String peerId = "ga";
    public static String clientId = "client";
    private P2PClientConfiguration p2pConfig;
    private P2PClient client;
    private EglBase rootEglBase;

    private static class Inner {
        private static P2PHelper inst = new P2PHelper();
    }

    public static P2PHelper getInst() {
        return Inner.inst;
    }

    private P2PHelper() {
        initP2PClientConfig();
    }

    public static void init(AppCompatActivity activity, P2PClient.P2PClientObserver observer) {
        getInst().initP2PClient(activity, observer);
    }

    private void initP2PClientConfig() {
        rootEglBase = EglBase.create();
        ContextInitialization.create()
                .setApplicationContext(MyApp.context)
                .setVideoHardwareAccelerationOptions(
                        rootEglBase.getEglBaseContext(),
                        rootEglBase.getEglBaseContext())
                .initialize();

        VideoEncodingParameters h264 = new VideoEncodingParameters(H264);
        VideoEncodingParameters h265 = new VideoEncodingParameters(H265);
        VideoEncodingParameters vp8 = new VideoEncodingParameters(VP8);
        VideoEncodingParameters vp9 = new VideoEncodingParameters(VP9);
        p2pConfig = P2PClientConfiguration.builder()
//                .addVideoParameters(vp9)
                .addVideoParameters(h264)
                .addVideoParameters(vp8)
                .addVideoParameters(h265)
                .build();
    }

    private void initP2PClient(AppCompatActivity activity, P2PClient.P2PClientObserver observer) {
        client = new P2PClient(p2pConfig, new SocketSignalingChannel());
        client.addObserver(observer);
        activity.getLifecycle().addObserver(new LifecycleObserver() {
            @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
            public void onDestory() {
                client.removeObserver(observer);
                client.disconnect();
                client.stop(P2PHelper.peerId);
                client.removeAllowedRemotePeer(P2PHelper.peerId);
            }
        });
    }

    public static P2PClient getClient() {
        return getInst().client;
    }

    public EglBase getRootEglBase() {
        return rootEglBase;
    }

    public P2PClientConfiguration getConfig() {
        return p2pConfig;
    }

    public abstract static class FailureCallBack<T> implements ActionCallback<T> {
        @Override
        public void onSuccess(T t) {
        }
    }
}
