package com.intel.gamepad.controller.impl;

public interface DeviceSwitchListtener {
    void switchKeyBoard();
    void switchMapperPad();
    void switchGamePad();
    void showDeviceMenu();
}